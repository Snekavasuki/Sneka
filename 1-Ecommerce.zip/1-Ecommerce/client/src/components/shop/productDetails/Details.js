import React, { Fragment } from "react";
import ProductDetailsSection from "./ProductDetailsSection";

const Details = (props) => {
  return (
    <Fragment>
      <ProductDetailsSection />
    </Fragment>
  );
};

export default Details;
